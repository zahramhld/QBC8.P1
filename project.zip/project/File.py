import csv
class File:
    
    @classmethod
    def writefile(cls,file, id, name, email, username, password,money = 0):
       with open(file ,"a+",newline='') as Users_list:
           Users_list.write(f"\n{id},{name},{email},{username},{password},{money}")
    @classmethod
    def writefile1(cls,file,id, name, lname, email, username, password):
       with open(file,"a+",newline='\n') as Employees_list:
           Employees_list.write(f"\n{id},{name},{lname},{email},{username},{password}")   
    
    @classmethod
    def readline(cls,file):
        with  open(file,'r') as Users_list:
            lines = csv.DictReader(Users_list) #first row as keys , other rows as values , each row will be a nested dictionary
            lines = list(lines)
        return lines
    
    
    @classmethod
    def writedic(cls,file,users):
        with open(file,"w",newline="") as Users_list:
            writer = csv.writer(Users_list) # make a writer object , after that we can use the methods that are defined for writer objects
            writer.writerow(users[0].keys())
            for user in users:
                writer.writerow(user.values())
# the reader method will read the lines and each line will be a nested list

#The seek() function in Python is used to move the file cursor to the specified location. 
#When we read a file, the cursor starts at the beginning, but we can move it to a specific position by passing
#an arbitrary integer (based on the length of the content in the file) to the seek() function.

#tell() function returns the position where the cursor is set to begin reading.