from Exception import *
from File import File

class Admin:
    Admin_username = "Admin_Train"
    Admin_password = "Pass_Train" 
    
    @classmethod
    def login(cls,username , password):
        if username != Admin.Admin_username or password != Admin.Admin_password:
            raise Admin_login_error("Invalid username or password")
        else:
            return True
        
    @classmethod
    def register(cls, name, lname, email, username, password):
        employees = File.readline("Employees.csv")
        if employees == []:
            id = len(employees)+1
            File.writefile1("Employees.csv",id,name, lname, email, username, password)
        else:
            for employee in employees:
                if employee["username"] == username:
                    raise Admin_register_error("There is Employee with same username")
                elif  employee["email"] == email:
                    raise Admin_register_error("There is Employee with same email")
                else: 
                    id = len(employees)+1
                    File.writefile1("Employees.csv",id,name, lname, email, username, password)
    @classmethod
    def removal(cls,username):
        employees = File.readline("Employees.csv")
        print(employees)
        for index,employee in enumerate(employees):
            if employee["username"] == username:
                del employees[index]
                print(employees)
                i = 1
                for employee in employees:
                    employee["id"] = i
                    i += 1
                break
        else:
            raise Admin_removal_error("Thre is not an Employee with this username") 
        File.writedic("Employees.csv", employees)
    
    @classmethod
    def show(cls):
        employees = File.readline("Employees.csv")
        return employees



        
            