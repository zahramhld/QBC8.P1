import random
from Exception import *
import os

class Input_checking:
    @classmethod
    def is_valid_name(cls,name):
        if not name.isalpha():
            raise Input_checking_error('name must only contains alphabet')
        if len(name)<3:
            raise Input_checking_error('The name must be at least three letters')
        if not 65 <= ord(name[0]) <= 90:
            raise Input_checking_error("The name must start with Uppercase letter.")
        else:
            return name
    
    @classmethod
    def is_valid_email(cls, email):
        if ' ' in email:
            raise Input_checking_error("Error: Email cannot contain spaces.")
        if '@' not in email or '.' not in email:
            raise Input_checking_error("Error: Email must contain both '@' and '.' symbols.")  
        if email.index('@') > email.index('.'):
            raise Input_checking_error("Error: The '.' symbol should come after '@'.") 
        domain = email.split('@')[1]  
        if domain != domain.lower():
            raise Input_checking_error("Error: The domain part of the email (after '@') must be in lowercase.")
        return email

    @classmethod
    def is_valid_username(cls,username):
        if len(username) < 4 or len(username) > 15:
            raise Input_checking_error("The username must be between 4 and 15 characters.")
        if not 65 <= ord(username[0]) <= 90:
            raise Input_checking_error("The username must start with Uppercase letter.")
        if not username.isidentifier():
            raise Input_checking_error("The username can only contain letters, numbers, and the underscore character.")
        if username.endswith('_'):
            raise Input_checking_error("The username can not end with an underscore character.")
        else:
            return username

    @classmethod
    def is_valid_password(cls,password):
            lenupper = 0
            lendigit = 0
            if len(password)<8:
                raise Input_checking_error("Password must be at least 8 characters.")
            for ch in password:
                if  ch.isupper():
                    lenupper += 1
                elif ch.isdigit():
                    lendigit += 1
            if lenupper == 0:
                raise Input_checking_error("At least one alphabet should be of Upper Case.")
            if lendigit == 0:
                raise Input_checking_error("It should At least contains one number.")
            if not ("_" in password or "@" in password or "$" in password):
                raise Input_checking_error("It should At least contains 1 character from [ _ or @ or $ ].")
            else:
                return password
    
    @classmethod
    def field_checking(cls,field,newvalue):
        if field == 'name':
            cls.is_valid_name(newvalue)
        if field == 'email':
            cls.is_valid_email(newvalue)
        if field == 'password':
            cls.is_valid_password(newvalue)
    
    @classmethod
    def get_valid_input(cls,Notif, valid):
        while True:
            try:
                Notif()
                user_input = input()
                valid(user_input)
                os.system('cls')
                return user_input
            except Input_checking_error as err:
                os.system('cls')
                print(err)