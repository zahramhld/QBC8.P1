import os
class Notification:
    @staticmethod
    def name():
        print("Enter name")
        print('1. Name must only contains alphabet.' ,
              '2. Name must be at least three letters.',
              '3. Name must start with Uppercase letter.', sep='\n')
    @staticmethod
    def lname():
        print("Enter last name")
        print('1. Last Name must only contains alphabet.' ,
              '2. Last Name must be at least three letters.',
              '3. Last Name must start with Uppercase letter.', sep='\n')
    @staticmethod
    def email():
        print("Enter email")
        print('1. Email cannot contain spaces.' ,
                   '2. Email must contain both @  and . symbols.',
                   '3. The . symbol should come after @ .',
                   '4. The domain part of the email (after @) must be in lowercase.', sep='\n')
    @staticmethod
    def username():
        print("Enter username")
        print('1. The username must be between 4 and 25 characters.' ,
                   '2. It must start with a letter.',
                   '3. It can only contain letters, numbers, and the underscore character.',
                   '4. It cannot end with an underscore character.',
                   '5. It must start with Uppercase letter', sep='\n')
    @staticmethod
    def password():
        print("Enter password")
        print('1. Password must be at least 8 characters.' ,
                   '2. At least one alphabet should be of Upper Case.',
                   '3. It should At least contains one number.',
                   '4. It should At least contains 1 character from [ _ or @ or $ ].', sep='\n')