import time
import os
from Exception import *
from Notifications import *
from Users import Users
from input_checking import Input_checking
from Admin import *



class TrainSystem:
    def __init__(self):
        self.system = {
            "lines": {},
            "trains": []
        }
    def add_train_line(self):
        while True:
            line_name = input("Enter line name: ")
            if line_name in self.system["lines"]:
                print("This line already exists, try again.")
            else:
                break

        beginning = input("Enter beginning name: ")
        end = input("Enter destination name: ")

        
        for line in self.system["lines"].values():
            if line["beginning"] == beginning and line["end"] == end:
                print(f"A train line with beginning {beginning} and destination {end} already exists.")
                return  

        while True:
            try:
                stations_numbers = input("Enter stations numbers or choose 'back' to return to menu: ")
                if stations_numbers.lower() == "back":
                    print("Back to the previous menu.")
                    return  
                stations_numbers = int(stations_numbers)
                break
            except ValueError:
                print("Invalid input. Please enter a valid number of stations.")

        while True:
            stations_name_list = input("Enter stations name (split with comma) or choose 'back' to return to menu: ").split(",")
            if stations_name_list[0].lower() == "back":
                print("Back to the previous menu.")
                return
            if len(stations_name_list) != stations_numbers:
                print("Stations number does not equal stations name.")
            else:
                break

        while True:
            try:
                total_distance = input("Please enter the distance between beginning and destination (km) or choose 'back' to return to menu: ")
                if total_distance.lower() == "back":
                    print("Back to the previous menu.")
                    return 
                total_distance = float(total_distance)
                break
            except ValueError:
                print("Invalid input. Please enter a valid distance.")

        stations_numbers += 2
        distance_per_station = total_distance / (stations_numbers - 1)

        self.system["lines"][line_name] = {
            "beginning": beginning,
            "end": end,
            "stations_numbers": stations_numbers,
            "stations_name_list": [beginning] + stations_name_list + [end],
            "total_distance": total_distance,
            "distance_per_station": distance_per_station
        }
        print(f"Line {line_name} entered successfully. Distance between each station: {distance_per_station:.2f} kilometers.")

    def update_info_train_line(self):
        while True:
            print("Update train line information")
            line_name = input("Please enter the train line name: ")

            if line_name not in self.system["lines"]:
                print("Train line name not found, try again.")
                add_line = input("Do you want to add a new train line? (yes/no): ")
                if add_line.lower() == "yes":
                    self.add_train_line()
                    break
                else:
                    print("Returning to update menu.")
                    return
            else:
                
                print("\nCurrent Information:")
                print(f"Beginning: {self.system['lines'][line_name]['beginning']}")
                print(f"End: {self.system['lines'][line_name]['end']}")
                print(f"Stations Number: {self.system['lines'][line_name]['stations_numbers']}")
                print(f"Stations List: {', '.join(self.system['lines'][line_name]['stations_name_list'])}")

                print("\nChoose an option:")
                print("1. Beginning")
                print("2. End")
                print("3. Station numbers")
                print("4. Station name list")
                choice = input("Choose an option: ")

                if choice == "1":
                    new_beginning = input("Enter new beginning: ")
                    self.system["lines"][line_name]["beginning"] = new_beginning
                    self.system["lines"][line_name]["stations_name_list"][0] = new_beginning
                elif choice == "2":
                    new_end = input("Enter new destination: ")
                    self.system["lines"][line_name]["end"] = new_end
                    self.system["lines"][line_name]["stations_name_list"][-1] = new_end
                elif choice == "3":
                    new_stations_numbers = int(input("Enter new train station numbers: "))
                    current_stations_numbers = self.system["lines"][line_name]["stations_numbers"]
                    
                    # حذف ایستگاه‌ها از انتهای لیست
                    if new_stations_numbers < current_stations_numbers:
                        stations_to_remove = current_stations_numbers - new_stations_numbers
                        self.system["lines"][line_name]["stations_name_list"] = self.system["lines"][line_name]["stations_name_list"][:-stations_to_remove]
                    
                    self.system["lines"][line_name]["stations_numbers"] = new_stations_numbers
                elif choice == "4":
                    station_list = input("Enter train station names (split with commas): ").split(",")
                    self.system["lines"][line_name]["stations_name_list"] = [station.strip() for station in station_list]
                    self.system["lines"][line_name]["stations_numbers"] = len(station_list)
                else:
                    print("You chose a wrong option. Returning to menu.")
                    return

                print(f"Line {line_name} updated successfully.")
                break


    def delete_train_line(self):
        line_name = input("Enter train line name to remove: ")
        
        if line_name not in self.system["lines"]:
            print("Line name not found, try again.")
            return

        
        related_trains = [train for train in self.system["trains"] if train["line_name"] == line_name]

        if related_trains:
            print(f"There are {len(related_trains)} trains on this line. Please remove the trains first.")
            for train in related_trains:
                print(f"Train name: {train['name']}")
            return

        
        del self.system["lines"][line_name]
        print(f"Line '{line_name}' removed successfully.")

    def show_line_list(self):
        if not self.system["lines"]:
            print("this line does not exists")
            add_line = input("do you want to add anew train line name?:")
            if add_line in ["yes"]:
                self.add_train_line()
            else:
                print("back to main menu")
            return
        print("train line lists")
        for line_name, line_info in self.system["lines"].items():
            print(f"line: {line_name}, beginning: {line_info['beginning']}, end: {line_info['end']}, station numbers: {line_info['stations_numbers']}, station name list: {', '.join(line_info['stations_name_list'])}")

        
    def add_train(self):  
        while True:  
            print("\n--- add train ---")
            
            while True:
                train_id = input("enter train ID or choose 'back' to return to menu:")
                if train_id.lower() == "back":
                    print("back to train employee panel")
                    return
                if any(train['id'] == train_id for train in self.system["trains"]):
                    print("a train with this ID exists, enter a unique ID")
                else:
                    break

            while True:
                train_name = input("enter train name or choose 'back' to return to menu:")
                if train_name.lower() == "back":
                    print("back to train employee panel")
                    return
                else:
                    break  

            while True:
                line_name = input("enter the train's line or choose 'back' to return to menu:")
                if line_name.lower() == "back":
                    print("back to train employee panel")
                    return
                if line_name not in self.system["lines"]:
                    print("this line does not exist, please enter line first")
                else:
                    break

            line_info = self.system["lines"][line_name]

            while True:
                try:
                    departure_time = input("please enter the start time with 'HH:MM format' or choose 'back' to return to menu:")
                    if departure_time.lower() == "back":
                        print("back to train employee panel")
                        return
                    hour, minute = map(int, departure_time.split(":"))
                    if not (0 <= hour <= 23 and 0 <= minute <= 59):
                        raise ValueError
                    break
                except ValueError:
                    print("time format is incorrect, please try again")

            while True:
                try:
                    speed = input("please enter train's speed 'km/h format' or choose 'back' to return to menu:")
                    if speed.lower() == "back":
                        print("back to train employee panel")
                        return
                    speed = float(speed)
                    break
                except ValueError:
                    print("Invalid input. Please enter a valid speed.")

            while True:
                try:
                    ticket_cost = input("please enter ticket's price or choose 'back' to return to menu:")
                    if ticket_cost.lower() == "back":
                        print("back to train employee panel")
                        return
                    ticket_cost = float(ticket_cost)
                    break
                except ValueError:
                    print("Invalid input. Please enter a valid ticket price.")

            while True:
                try:
                    capacity = input("please enter train's capacity or choose 'back' to return to menu:")
                    if capacity.lower() == "back":
                        print("back to train employee panel")
                        return
                    capacity = int(capacity)
                    break
                except ValueError:
                    print("Invalid input. Please enter a valid capacity.")

            while True:
                try:
                    quality = input("please enter train's quality (1-5) or choose 'back' to return to menu:")
                    if quality.lower() == "back":
                        print("back to train employee panel")
                        return
                    quality = int(quality)
                    if quality in range(1, 6):
                        quality_stars = "*" * quality
                        break
                    else:
                        print("train's quality must be between 1-5")
                except ValueError:
                    print("Invalid input. Please enter a valid quality (1-5).")

            quality_stars = "*" * quality
            distance_per_station = line_info["distance_per_station"]
            time_per_station = (distance_per_station / speed) * 60
            stop_time = 20
            collision_detected = False
            for train in self.system["trains"]:
                if train["line_name"] == line_name:
                    train_departure_hour, train_departure_minute = map(int, train["departure_time"].split(":"))
                    train_speed = train["speed"]
                    train_stop_time = 20
                    train_distance_per_station = train["distance_per_station"]
                    train_time_per_station = (train_distance_per_station / train_speed) * 60

                    for i in range(line_info["stations_numbers"] + 1):
                        new_train_arrival = (hour * 60 + minute) + i * (time_per_station + stop_time)
                        existing_train_arrival = (train_departure_hour * 60 + train_departure_minute) + i * (train_time_per_station + train_stop_time)

                        if abs(new_train_arrival - existing_train_arrival) < 20:
                            collision_detected = True
                            print(f"Train '{train_name}' (ID: {train_id}) may cross with existing train '{train['name']}' (ID: {train['id']}) in station {i + 1}")
                        break

                    if collision_detected:
                        break

            if collision_detected:
                print("you can't add this train!")
                continue

            train_data = {
                "id": train_id,
                "name": train_name,
                "line_name": line_name,
                "speed": speed,
                "departure_time": departure_time,
                "ticket_cost": ticket_cost,
                "capacity": capacity,
                "quality": quality_stars,
                "distance_per_station": distance_per_station,
                "num_stations": line_info["stations_numbers"]
            }

            self.system["trains"].append(train_data)
            print(f"train '{train_name}',(ID: {train_id}) added successfully")
            break




    def delete_train(self):
        while True:

            train_name = input("enter train name to remove: ")
            if train_name not in self.system["trains"]:
                print("train name does not found,try again")
                continue_ = input("do you want to continue؟:")
                if continue_ in ["no"]:
                    print("back to main manu")
                    break 
            else:
                self.system["trains"].remove(train_name)
                print(f"train {train_name} removed succsesfully")
                break 
            
    def show_trains_list(self): 
        if not self.system["trains"]: 
            print("train not found") 
            add_train = input("do you want to add a new train؟:") 
            if add_train in ["yes", "Yes"]: 
                self.add_train() 
            else: 
                print("back to main menu") 
            return     

        print("\ntrains list:")
        for idx, train in enumerate(self.system["trains"], start=1): 
            print(f"""
            train information:
            train name: {train['name']}
            train ID: {train["id"]}
            train line: {train['line_name']}
            beginning: {self.system['lines'][train['line_name']]['beginning']}
            destination: {self.system['lines'][train['line_name']]['end']}
            train stations numbers: {self.system['lines'][train['line_name']]['stations_numbers']}
            train stations name: {', '.join(self.system['lines'][train['line_name']]['stations_name_list'])}
            speed: {train['speed']} km/h
            20 min : pause time in each station
            movment time: {train['departure_time']}
            tickets price: {train['ticket_cost']}
            capicity: {train['capacity']}
            quality: {train['quality']}
            """)
    def start_panel(self):

        while True: 
            print("\n--- start menu ---")
            print("1. admin")
            print("2. train employee")
            print("3. user")
            print("4. logout", sep="\n")

            order = input("choose an option: ")

            if order == "1":
                os.system("cls" if os.name == "nt" else "clear")
                while True:
                    username = input("Please Enter your username or type 'back' to return to menu: ")
                    if username.lower() == "back":
                        os.system("cls" if os.name == "nt" else "clear")
                        break
                    
                    password = input("Please Enter your password or type 'back' to return to menu: ")
                    if password.lower() == "back":
                        os.system("cls" if os.name == "nt" else "clear")
                        break
                    
                    try:
                        Admin.login(username, password)
                        return self.admin_panel()
                    except Admin_login_error as err:
                        os.system("cls" if os.name == "nt" else "clear")
                        print(err)


            elif order == "2":
                self.the_panel()
            
            elif order == "3":
                os.system("cls" if os.name == "nt" else "clear")
                return self.user_panel()

            
            elif order == "4":
                os.system("cls" if os.name == "nt" else "clear")
                exit("Bye")
            else:
                os.system("cls" if os.name == "nt" else "clear")
                print("Wrong")
                return self.start_panel()
        
    def admin_panel(self):
            print("--- Admin Panel ---",
                "1. Adding Employee",
                "2. Removing Employee",
                "3. View List of Employees",
                "4. Exit Admin Panel" , sep = "\n")
            order = input("choose an option: ")
            if order == "1":
                os.system("cls" if os.name == "nt" else "clear")
                print("Type Back to return")
                while True:
                    try:
                        name = Input_checking.get_valid_input(Notification.name, Input_checking.is_valid_name)
                        if name == "Back":
                          return self.admin_panel()
                        lname = Input_checking.get_valid_input(Notification.lname, Input_checking.is_valid_name)
                        if lname == "Back":
                          return self.admin_panel()
                        email = Input_checking.get_valid_input(Notification.email, Input_checking.is_valid_email)
                        if email == "Back":
                          return self.admin_panel()
                        username = Input_checking.get_valid_input(Notification.username, Input_checking.is_valid_username)
                        if username == "Back":
                          return self.admin_panel()
                        password = Input_checking.get_valid_input(Notification.password, Input_checking.is_valid_password)
                        if password == "Back":
                          return self.admin_panel()
                        Admin.register(name, lname, email, username, password)
                        os.system("cls" if os.name == "nt" else "clear")
                        print("Employee is added!")
                        return self.admin_panel()

                    except Admin_register_error as err:
                        os.system("cls" if os.name == "nt" else "clear")
                        print(err)
                        return self.admin_panel()
            if order == "2":
                print("Please Enter Employeess username:")
                try:
                    order = input()
                    Admin.removal(order)
                    return self.admin_panel()
                except Admin_removal_error as err:
                    os.system("cls" if os.name == "nt" else "clear")
                    print(err)
                    return self.admin_panel()

            if order == "3":
                print(Admin.show())
                print()
                time.sleep(3)
                self.admin_panel()

            if order == "4":
                os.system("cls" if os.name == "nt" else "clear")
                return self.start_panel()

            else:
                os.system("cls" if os.name == "nt" else "clear")
                print("Wrong")
                return self.start_panel()
        
    def user_panel(self):
            print("--- User Panel ---",
                "1. register",
                "2. login",
                "3. return", sep="\n")
            order = input("choose an option: ")

            if order == "1":
                os.system("cls" if os.name == "nt" else "clear")
                print("Type Back to return")
                while True:
                    try:
                        name = Input_checking.get_valid_input(Notification.name, Input_checking.is_valid_name)
                        if name == "Back":
                          return self.admin_panel()
                        email = Input_checking.get_valid_input(Notification.email, Input_checking.is_valid_email)
                        if email == "Back":
                          return self.admin_panel()
                        username = Input_checking.get_valid_input(Notification.username, Input_checking.is_valid_username)
                        if username == "Back":
                          return self.admin_panel()
                        password = Input_checking.get_valid_input(Notification.password, Input_checking.is_valid_password)
                        if password == "Back":
                          return self.admin_panel()
                        Users.register(name, email, username, password)
                        os.system("cls" if os.name == "nt" else "clear")
                        print("Your account has been created!")
                        return self.user_panel()
                    except Users_register_error as err:
                        os.system("cls" if os.name == "nt" else "clear")
                        print(err)
                        return self.user_panel()

            elif order == "2":
                os.system("cls" if os.name == "nt" else "clear")
                print("Enter username: ")
                username = input()
                print("Enter password: ")
                password = input()
                try:
                    my_user = Users.login(username, password)
                    os.system("cls" if os.name == "nt" else "clear")
                    print("You logged in!")
                    return self.buy_panel(my_user)

                except Users_login_error as err:
                    os.system("cls" if os.name == "nt" else "clear")
                    print(err)
                    return self.user_panel()

            elif order == "3":
                os.system("cls" if os.name == "nt" else "clear")
                return self.start_panel()
            else:
                os.system("cls" if os.name == "nt" else "clear")
                print("Wrong!")
                return self.user_panel()

        
    def buy_panel(self, user):
            my_user = user
            print("--- Buy Panel ---",
                "1. buy ticket",
                "2. edit profile",
                "3. Exit" , sep = "\n")
            order = input("choose an option: ")
            if order == "1":
                self.buy_ticket(my_user,self.system["trains"])
            
            elif order == "2":
                os.system("cls" if os.name == "nt" else "clear")
                return self.edit_panel(my_user)
            
            elif order == "3":
                os.system("cls" if os.name == "nt" else "clear")
                return self.user_panel()
            
            else:
                os.system("cls" if os.name == "nt" else "clear")
                print("Wrong!")
                return self.buy_panel(my_user)
        
    def addmoney(self,user):
        print("Add money to your wallet:")
        card_number = input("Enter card number (16 digits): ")
        cvv2 = input("Enter CVV2 (3 digits): ")
        if self._validate_card(card_number, cvv2):
            try:
                amount = int(input("Enter the amount you want to add: "))
                if amount > 0:
                    user["money"] = int(user["money"]) + amount
                    users = File.readline("Users.csv")
                    for index,useri in enumerate(users):
                        if useri['id'] == user['id']:
                            users[index] = user
                            break  
                    File.writedic('Users.csv',users)
                    os.system("cls" if os.name == "nt" else "clear")
                    print(f"The amount {amount} has been added to your wallet. Total balance is {user["money"]}.")
                    return self.buy_panel(user)
                else:
                    print("The amount must be greater than zero.")
                    return self.buy_panel(user)

            except ValueError:
                print("Invalid input! Please enter a valid amount.")
                return self.buy_panel(user)
        else:
            print("Invalid card details. Please try again.")
            return self.buy_panel(user)
    def _validate_card(self,card_number, cvv2):
        """اعتبارسنجی کارت بانکی."""
        return len(card_number) == 16 and card_number.isdigit() and len(cvv2) == 3 and cvv2.isdigit()
    
    
    
    def buy_ticket(self,user,trains):
        print("--- Buy Ticket ---",
                "1. Purchase Ticket",
                "2. Add Money",
                "3. Exit" , sep = "\n")
        order = input("choose an option: ")
        if order == "1":
            if not self.system["trains"]: 
                os.system("cls" if os.name == "nt" else "clear")
                print("No Trains availabe")
                return self.buy_panel(user)
            else:
                print("\ntrains list:")
                for idx, train in enumerate(self.system["trains"], start=1): 
                    print(f"""
                        train information:
                        train name: {train['name']}
                        train ID: {train["id"]}
                        train line: {train['line_name']}
                        beginning: {self.system['lines'][train['line_name']]['beginning']}
                        destination: {self.system['lines'][train['line_name']]['end']}
                        train stations numbers: {self.system['lines'][train['line_name']]['stations_numbers']}
                        train stations name: {', '.join(self.system['lines'][train['line_name']]['stations_name_list'])}
                        speed: {train['speed']} km/h
                        20 min : pause time in each station
                        movment time: {train['departure_time']}
                        tickets price: {train['ticket_cost']}
                        capicity: {train['capacity']}
                        quality: {train['quality']}""")
                train_id = input("\nEnter the Train ID to purchase a ticket: ")
                for train in self.system["trains"]:
                    flag = True
                    if train['id'] == train_id:
                        flag == False
                        if int(train['capacity']) > 0:
                            if int(user['money']) >= train['ticket_cost']:
                                train['capacity'] = int(train['capacity']) - 1
                                user["money"] = int(user["money"]) - int(train['cost'])
                                users = File.readline("Users.csv")
                                for index,useri in enumerate(users):
                                    if useri['id'] == user['id']:
                                        users[index] = user
                                        break  
                                File.writedic('Users.csv',users)
                                os.system("cls" if os.name == "nt" else "clear")
                                print(f"\nTicket successfully purchased for train {train['name']}!")
                                return self.buy_panel(user)
                            else:
                                return self.addmoney(user)
                        else:
                            os.system("cls" if os.name == "nt" else "clear")
                            print("\nSorry, this train is fully booked.")
                            return self.buy_panel(user)
                            break
                if flag == True:
                        os.system("cls" if os.name == "nt" else "clear")
                        print("\nInvalid Train ID.")
                        return self.buy_panel(user)
        elif order == "2":
                os.system("cls" if os.name == "nt" else "clear")
                self.addmoney(user)
        elif order == "3":
            os.system("cls" if os.name == "nt" else "clear")
            return self.user_panel()  
        else:
            os.system("cls" if os.name == "nt" else "clear")
            print("Wrong!")
            return self.user_panel()
    
    def edit_panel(self,user) :
            my_user = user
            print("--- Edit profile panel ---",
            "1. View your profile",
            "2. Edit your profile",
            "3. Return to Buy Panel", sep = "\n")
            order = input("choose an option: ")
                
            if order == "1":
                os.system("cls" if os.name == "nt" else "clear")
                (Users.profile(my_user))
                print()
                time.sleep(2)
                self.edit_panel(my_user)
                
            if order == "2":
                os.system("cls" if os.name == "nt" else "clear")
                Users.profile(my_user)
                print()
                field = input('Which field do you want to change? ')
                if field == 'username':
                    os.system("cls" if os.name == "nt" else "clear")
                    print("You can't change your username! please try again")
                    return self.edit_panel(my_user)
                if not (field =='name' or field == 'email' or field == 'password'):
                    os.system("cls" if os.name == "nt" else "clear")
                    print("Please enter a correct field, the correct fields are name, email and password")
                    return self.edit_panel(my_user)
                
                else:
                    temp_my_user = my_user.copy()
                    oldvalue = my_user[field]
                    newvalue = input(f"Your {field} right now is {oldvalue}, You want to change it to : ")
                    temp_my_user[field] = newvalue
                    try:
                        Input_checking.field_checking(field,newvalue)
                        Users.edit_profile(temp_my_user,field)
                        Users.profile(temp_my_user)
                        return self.edit_panel(temp_my_user)
                    except Input_checking_error as err:
                        os.system("cls" if os.name == "nt" else "clear")
                        print(err)
                        return self.edit_panel(my_user)
                    
                    except Edit_profile_error as err:
                        os.system("cls" if os.name == "nt" else "clear")
                        print(err)
                        return self.edit_panel(my_user)
                    
            
            if order == "3":
                os.system("cls" if os.name == "nt" else "clear")
                return self.buy_panel(my_user)
            
            else:
                os.system("cls" if os.name == "nt" else "clear")
                print("Wrong")
                return self.st(my_user)

    def the_panel(self):
        while True:
            print("\nemployee panel options:")
            print("1. add train line")
            print("2. update info train line")
            print("3. delete train line")
            print("4. show line list")
            print("5. add train")
            print("6. delete train")
            print("7. show trains list")
            print("8. log out")

            option = input("choose an option: ")
        
            if option == "1":
                self.add_train_line() 
            if option == "2":
                self.update_info_train_line()   
            if option == "3":
                self.delete_train_line()  
            if option == "4":
                self.show_line_list()  
            if option == "5":
                self.add_train()    
            if option == "6":
                self.delete_train()
            if option == "7":
                self.show_trains_list()   
            if option == "8":
                print("logging out train employee panel!")
                self.start_panel()  
            else:
                print("option unvalid,try again")

  


def main():
    system = TrainSystem()
    system.start_panel()

if __name__ == "__main__":
    main()