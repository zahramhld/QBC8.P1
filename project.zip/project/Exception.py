class Users_login_error(Exception):
    pass

class Users_register_error(Exception):
    pass

class Edit_profile_error(Exception):
    pass

class Input_checking_error(Exception):
    pass

class Admin_login_error(Exception):
    pass
class Admin_register_error(Exception):
    pass

class Admin_removal_error(Exception):
    pass