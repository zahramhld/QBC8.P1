from Exception import *
from File import *

class Users:       
    
    @classmethod
    def register(cls, name, email, username, password, money = 0):
        users = File.readline("Users.csv")
        if users == []:
            id = len(users)+1
            File.writefile("Users.csv",id,name, email, username, password,money)
        else:
            for user in users:
                if user["username"] == username:
                    raise Users_register_error("There is User with same username")
                elif  user["email"] == email:
                    raise Users_register_error("There is User with same email")
                else: 
                    id = len(users)+1
                    File.writefile("Users.csv",id,name, email, username, password,money)                

    @classmethod            
    def login(cls, username, password):
        users = File.readline('Users.csv')
        i = 0
        for user in users:
            if user["username"] == username:
                if user["password"] == password:
                    return user
                else:
                    raise Users_login_error("Invalid password")
            else:
                i += 1
                if i == len(users):
                    raise Users_login_error("Invalid username")
            
        raise Users_login_error("You must register first!")
    
    def buy_ticket(self):
        pass
    
    @classmethod
    def profile(cls,user):
        print('Your information right now is : ')
        for k,v in user.items():
            if k != 'id':
                print(f'{k} : {v}')
    
    @classmethod
    def edit_profile(cls,my_user,field):
        users = File.readline("Users.csv")
        if field == "email":
            duplicate = 0
            for user in users:
                if user["email"] == my_user["email"]:
                    duplicate +=1
            if duplicate != 0:
                raise Edit_profile_error("There is User with same email")
            else:
                for index,user in enumerate(users):
                    if user['id'] == my_user['id']:
                        users[index] = my_user
                        break
        else:
          for index,user in enumerate(users):
            if user['id'] == my_user['id']:
                users[index] = my_user
                break  
        File.writedic('Users.csv',users)